package repository;

import usuarios.Usuario;

import java.io.*;
import java.nio.file.*;
import java.util.Optional;

public class FileUsuarioRepository implements UsuarioRepository {
    private final Path filePath;
    private final String separator = ";";

    public FileUsuarioRepository(String filepath)throws IOException{
        this.filePath = Paths.get(filepath);
        if (Files.notExists(filePath)) {
            Files.createDirectories(filePath.getParent() == null ? Paths.get(".") : filePath.getParent());
            Files.createFile(filePath);
        }
    }

    @Override
    public boolean existsByEmail(String email) throws IOException {
        try (BufferedReader br = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = br.readLine()) != null) {
                String [] parts = line.split(separator, 2);
                if (parts.length >0 && parts[0].equalsIgnoreCase(email)) return true;
            }
        }
        return false;
    }

    @Override
    public void save(Usuario usuarios) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(filePath, StandardOpenOption.APPEND)) {
            bw.write(usuarios.getEmail() + separator + usuarios.getPassword());
            bw.newLine();
        }
    }

    @Override
    public Optional<Usuario> findByEmail(String email) throws IOException {
        try (BufferedReader br = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(separator, 2);
                if (parts.length > 0 && parts[0].equalsIgnoreCase(email)) {
                    String pwd = parts.length > 1 ? parts[1] : "";
                    return Optional.of(new Usuario(parts[0], pwd));
                }
            }
        }
        return Optional.empty();
    }
}

