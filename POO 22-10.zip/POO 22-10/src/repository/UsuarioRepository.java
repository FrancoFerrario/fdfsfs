package repository;

import usuarios.Usuario;
import java.io.IOException;
import java.util.Optional;

public interface UsuarioRepository {
    boolean existsByEmail(String email) throws IOException;
    void save (Usuario usuario) throws IOException;
    Optional<Usuario> findByEmail(String email) throws IOException;
}
