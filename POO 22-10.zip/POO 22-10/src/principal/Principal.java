package principal;

import controller.UsuarioController;
import repository.FileUsuarioRepository;
import servicio.UsuarioServicio;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Principal {
    public static void main(String[] args) {
        // archivo donde se guardan los usuarios (ruta relativa al proyecto)
        String file = "data/users.csv";

        // inicializar repositorio, servicio y controlador
        FileUsuarioRepository repo;
        try {
            repo = new FileUsuarioRepository(file);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "No se pudo crear/abrir el archivo de usuarios: " + e.getMessage());
            return;
        }
        UsuarioServicio service = new UsuarioServicio(repo);
        UsuarioController controller = new UsuarioController(service);

        // crear GUI en Event Dispatch Thread
        SwingUtilities.invokeLater(() -> createAndShowGUI(controller));
    }

    private static void createAndShowGUI(UsuarioController controller) {
        JFrame frame = new JFrame("Registro de Usuarios");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 260);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel lblEmail = new JLabel("Correo:");
        lblEmail.setBounds(20, 20, 100, 25);
        panel.add(lblEmail);

        JTextField txtEmail = new JTextField();
        txtEmail.setBounds(120, 20, 260, 25);
        panel.add(txtEmail);

        JLabel lblPwd = new JLabel("Clave:");
        lblPwd.setBounds(20, 60, 100, 25);
        panel.add(lblPwd);

        JPasswordField txtPwd = new JPasswordField();
        txtPwd.setBounds(120, 60, 260, 25);
        panel.add(txtPwd);

        JButton btnRegister = new JButton("Registrar");
        btnRegister.setBounds(120, 110, 120, 30);
        panel.add(btnRegister);

        JButton btnClear = new JButton("Limpiar");
        btnClear.setBounds(260, 110, 120, 30);
        panel.add(btnClear);

        JLabel lblInfo = new JLabel("<html>Contraseña: min 8, mayúscula, minúscula, número y símbolo (sin coma)</html>");
        lblInfo.setBounds(20, 150, 380, 40);
        panel.add(lblInfo);

        btnRegister.addActionListener(e -> {
            String email = txtEmail.getText().trim();
            String password = new String(txtPwd.getPassword());
            String result = controller.handleRegister(email, password);
            JOptionPane.showMessageDialog(frame, result);
        });

        btnClear.addActionListener(e -> {
            txtEmail.setText("");
            txtPwd.setText("");
        });

        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }
}
