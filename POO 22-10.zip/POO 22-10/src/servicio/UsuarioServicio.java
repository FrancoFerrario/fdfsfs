package servicio;

import usuarios.Usuario;
import repository.UsuarioRepository;
import repository.UsuarioRepository;

import java.io.IOException;
import java.util.regex.Pattern;

public class UsuarioServicio {
    private final UsuarioRepository repo;

    public UsuarioServicio(UsuarioRepository repo) {
        this.repo = repo;
    }

    // valida email (simple, suficiente para la consigna)
    private static final Pattern EMAIL_REGEX =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    public boolean isEmailValid(String email) {
        if (email == null) return false;
        return EMAIL_REGEX.matcher(email).matches();
    }

    // validación de contraseña: mínimo 8, 1 mayúscula, 1 minúscula, 1 dígito, 1 símbolo especial (no coma)
    public boolean isPasswordValid(String password) {
        if (password == null) return false;
        if (password.length() < 8) return false;
        boolean hasUpper = password.chars().anyMatch(ch -> Character.isUpperCase(ch));
        boolean hasLower = password.chars().anyMatch(ch -> Character.isLowerCase(ch));
        boolean hasDigit = password.chars().anyMatch(ch -> Character.isDigit(ch));
        boolean hasSpecial = password.chars().anyMatch(ch -> !Character.isLetterOrDigit(ch));
        boolean containsComma = password.indexOf(',') >= 0;
        return hasUpper && hasLower && hasDigit && hasSpecial && !containsComma;
    }

    public String registerUser(String email, String password) {
        try {
            if (!isEmailValid(email)) {
                return "El usuario debe ser un correo electrónico válido.";
            }
            if (!isPasswordValid(password)) {
                return "La clave debe tener mínimo 8 caracteres, incluir mayúscula, minúscula, número y símbolo especial (no coma).";
            }
            if (repo.existsByEmail(email)) {
                return "Ya existe un usuario con ese correo.";
            }
            Usuario user = new Usuario(email, password);
            repo.save(user);
            return "Usuario registrado correctamente.";
        } catch (IOException e) {
            e.printStackTrace();
            return "Error al acceder al archivo de usuarios: " + e.getMessage();
        }
    }
}
