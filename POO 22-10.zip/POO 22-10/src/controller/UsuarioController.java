package controller;

import servicio.UsuarioServicio;

public class UsuarioController {
    private final UsuarioServicio service;

    public UsuarioController(UsuarioServicio servicio) {
        this.service = servicio;
    }

    public String handleRegister(String email, String password) {
        return service.registerUser(email, password);
    }
}
